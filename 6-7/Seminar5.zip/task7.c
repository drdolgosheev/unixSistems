#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

void reverse(char* str, size_t sz);

int main()
{
    int fd1[2], fd2[2], result;
    size_t size;
    char resstring[14];

    /* Попытаемся создать pipe */
    if (pipe(fd1) < 0) {
        printf("Can\'t create parent pipe\n");
        exit(-1);
    }

    /* Попытаемся создать pipe */
    if (pipe(fd2) < 0) {
        printf("Can\'t create child pipe\n");
        exit(-1);
    }

    //порождаю процесс
    result = fork();
    if (result < 0)
    {
        /* Если создать процесс не удалось, сообщаем об этом и завершаем работу */
        printf("Can\'t fork child\n");
        exit(-1);
    } else if (result > 0) {
        // родитель
        close(fd1[0]); //закрыть чтение у родителя
        close(fd2[1]); //закрыть запись у ребенка
        size = write(fd1[1], "Hello, world!", 14);
        if (size != 14) {
            printf("Can\'t write all string\n");
            exit(-1);
        }
        close(fd1[1]); // закрыть запись у родителя

        size = read(fd2[0], resstring, 14);
        if (size != 14) {
            printf("Can\'t read from child\n");
            exit(-1);
        }
        printf("Parent got from child: %s\n", resstring);
        printf("Parent exit\n");
    } else//если ребенок
        {
        close(fd1[1]); // закрыть запись у родителя
        close(fd2[0]); // закрыть чтение у ребенка
        size = read(fd1[0], resstring, 14);
        if (size < 0) {
            printf("Can\'t get from parent\n");
            exit(-1);
        }
        printf("Got from parent: %s\n", resstring);
        reverse(resstring, 13);
        size = write(fd2[1], resstring, 14);
        close(fd1[0]); // закрыть чтение у родителя
        printf("Exit child\n");
    }
    return 0;
}

void reverse(char* str, size_t sz)
{
    for (int i = 0; i < sz / 2; i++) {
        char t = str[i];
        str[i] = str[sz - i - 1];
        str[sz - i - 1] = t;
    }
}
